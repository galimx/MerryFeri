<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
	<title>rezervacije.si</title>	
	<link rel="shortcut icon" href="image/favicon.ico" />
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="content-language" content="en-gb" />
	<meta http-equiv="imagetoolbar" content="false" />
	<meta name="author" content="Christopher Robinson" />
	<meta name="copyright" content="Copyright (c) Christopher Robinson 2005 - 2007" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />	
	<meta name="last-modified" content="Sat, 01 Jan 2007 00:00:00 GMT" />
	<meta name="mssmarttagspreventparsing" content="true" />	
	<meta name="robots" content="index, follow, noarchive" />
	<meta name="revisit-after" content="7 days" />
</head>

<script language="javascript">
function izbira(tipka, x, y) {
	var rdeca = "#FF0000";
	var link = "http://localhost/PIS/rezezviraj.php?vrsta=" + x + "&sedez=" + y;
	window.location = link;
}

function preko(tipka) {
	var rdeca = "#FF0000";
	tipka.style.backgroundColor = rdeca;
}

</script>


<body>
<div id="header">
		<div id="header_inside">
			<h1><span>rezervacije</span>.si</h1>
			<ul>
            	<li><a href="profil.php">Profil</a></li>		
				<li><a href="rezerviraj.php">Rezervacije</a></li>
                <li><a href="index.php">Domov</a></li>
			</ul>		
		</div>
	</div>

	<div id="content">
		<div id="content_inside">
			<div id="content_inside_sidebar">
                <form name="form" method="post">
                <h2>Prijava</h2>
                <ul id="prijavniObrazec">
					<li>Uporabnik: <input name="uporabnik" type="text" size="14.5"></li>
                    <li>Geslo: <input name="geslo" type="password" size="18"></li>
                    <li style="float:right"><input name="potrdi" type="submit" value="Prijava"></li>
				</ul>
                </form>
				<h2>Povezave</h2>
				<ul>
					<li><a href="http://www.google.si/">Google</a></li>
                    <li><a href="http://www.zurnal24.si/">Žurnal24</a></li>
                    <li><a href="http://www.24ur.com/">24ur</a></li>
                    <li><a href="http://www.nogomania.com/">Nogomania</a></li>
				</ul>
                <h2>Novice</h2>
				<ul>
					<li><a href="http://www.google.si/">Google</a></li>
                    <li><a href="http://www.zurnal24.si/">Žurnal24</a></li>
                    <li><a href="http://www.24ur.com/">24ur</a></li>
                    <li><a href="http://www.nogomania.com/">Nogomania</a></li>
				</ul>
			</div>
			<div id="content_inside_main">
			<?php
				//povezava na bazo
				include("povezi.php");
				$sifraDogodka = 1;
				
				//privzeto
				$visina = 10;
				$sirina = 10;
				
				echo "
				<form method=\"post\">
				Število sedežev: <select name=\"sirina\">";
				for ($s = 1; $s <= 20; $s++)
				echo "<option>" . $s . "</option>";
				echo "</select>
				<br />
				Število vrst: <select name=\"visina\">";
				for ($v = 1; $v <= 20; $v++)
				echo "<option>" . $v . "</option>";
				echo "</select>
				<input type=\"submit\" value=\"Kreiraj dvorano\" />
				</form>";
				
				if (isset($_POST["visina"]) && isset($_POST["sirina"])) {
					$visina = $_POST["visina"];
					$sirina = $_POST["sirina"];
				}
				
				echo "<br />";	
				echo "
				<table border=none>";
				
				echo '
				<tr>
					<td colspan="' . $sirina. '" align="center">
						<img src="slike/platno.jpg" width="300px" height="150px">
					</td>
				</tr>';
				
				for ($i = 1; $i <= $visina; $i++) {
				echo "<tr>";
				
				for ($j = 1; $j <= $sirina; $j++) {
				$query = "SELECT * FROM `" . $sifraDogodka . "` WHERE vrsta=".$i." AND sedez=" . $j;
				$result = mysql_query($query) or die("Napačen query!");
				$rows = mysql_num_rows($result);	
				
				if ($rows == 0)
					echo "
						<td id=\"sedezProsto\" onClick=\"izbira(this, ".$i.", ".$j.")\">
						&nbsp;
						</td>";
				else if ($rows == 1)	
					echo "
						<td id=\"sedezZasedeno\">
						&nbsp;
						</td>";
				else 
					echo "Error";
				}
				echo "</td>";
				}
				echo "</table>";
			?>
			</div>	
		</div>	
	</div>
	<div id="footer">
		<div id="footer_inside">
			<p>Copyright &copy; 2012</p>
		</div>
	</div>
</body>
</html>