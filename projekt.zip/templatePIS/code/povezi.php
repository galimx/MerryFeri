<?php
	$server = "localhost";
	$username = "root";
	$password = "123455";
	$database = "rezervacije";
	$con = mysql_connect($server, $username, $password) OR DIE (mysql_error());
	@mysql_select_db ($database, $con) OR DIE (mysql_error());
?>