<?php

$vrsta = $_GET["vrsta"];
$sedez = $_GET["sedez"];

echo "Poteka rezervacija: VRSTA: " . $vrsta . " SEDEZ: " .$sedez;

?>
