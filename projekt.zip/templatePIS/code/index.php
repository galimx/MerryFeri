<link href="css/style.css" type="text/css" rel="stylesheet" title="default" />
<script language="javascript">
function izbira(tipka, x, y) {
	var rdeca = "#FF0000";
	var link = "http://localhost/PIS/rezezviraj.php?vrsta=" + x + "&sedez=" + y;
	window.location = link;
}

function preko(tipka) {
	var rdeca = "#FF0000";
	tipka.style.backgroundColor = rdeca;
}

</script>

<body>
<div id="menu">
	<ul>
		<li><a href="#">Domov</a></li>
        <li><a href="#">Brskaj</a></li>
        <li><a href="#">Profil</a></li>
	</ul>
<div id="telo">
<?php
	//povezava na bazo
	include("povezi.php");
	$sifraDogodka = 1;
	
	//privzeto
	$visina = 10;
	$sirina = 10;
	
	echo "
	<div id=\"nastavitveDvorane\">
	<form method=\"post\">
	X: <select name=\"sirina\">";
  	for ($s = 1; $s <= 50; $s++)
	echo "<option>" . $s . "</option>";
	echo "</select>
	<br />
	Y: <select name=\"visina\">";
	for ($v = 1; $v <= 50; $v++)
	echo "<option>" . $v . "</option>";
	echo "</select>
	<input type=\"submit\" value=\"Kreiraj dvorano\" />
	</form>
	</div>";
	
	if (isset($_POST["visina"]) && isset($_POST["sirina"])) {
		$visina = $_POST["visina"];
		$sirina = $_POST["sirina"];
	}
	
	echo "<br />";	
	echo "<table border=none>";
	
	echo '
	<tr>
		<td colspan="' . $sirina. '" align="center">
			<img src="slike/platno.jpg" width="300px" height="150px">
		</td>
	</tr>';
	
	for ($i = 1; $i <= $visina; $i++) {
	echo "<tr>";
	
	for ($j = 1; $j <= $sirina; $j++) {
	$query = "SELECT * FROM `" . $sifraDogodka . "` WHERE vrsta=".$i." AND sedez=" . $j;
	$result = mysql_query($query) or die("Napačen query!");
	$rows = mysql_num_rows($result);	
	
	if ($rows == 0)
		echo "
			<td id=\"sedezProsto\" onClick=\"izbira(this, ".$i.", ".$j.")\">
			&nbsp;
			</td>";
	else if ($rows == 1)	
		echo "
			<td id=\"sedezZasedeno\">
			&nbsp;
			</td>";
	else 
		echo "Error";
	}
	echo "</td>";
	}
	echo "</table>";
?>
</div>
</div>
</body>